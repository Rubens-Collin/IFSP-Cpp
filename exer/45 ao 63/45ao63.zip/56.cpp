#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <locale>
using namespace std;
 main()
{
//comandos do programa
setlocale(LC_ALL,"PORTUGUESA");

int idade,altura,sexo,saude;
char nome[20];

cout << "saldado 1\n";
cout << "digite seu nome\n";
cin>> nome;
cout << "digite seu sexo sendo 1 para masculino e 2 para feminino \n";
cin >> sexo;
cout << "digite sua saude sendo 1 para boa e 2 para ruim\n";
cin >> saude;
cout<< "digite sua idade\n";
cin >> idade;
cout << "digite sua altura em centimetros\n";
cin >> altura;

if (sexo==1 and saude==1 and idade==18 and altura>=170 )
{
    cout << "bem vindo ao exercito soldado "<<nome<<"\n";
}
else
{
    cout << ""<<nome<<" voce foi liberado\n";
}

cout << "saldado 2\n";
cout << "digite seu nome\n";
cin>> nome;
cout << "digite seu sexo sendo 1 para masculino e 2 para feminino \n";
cin >> sexo;
cout << "digite sua saude sendo 1 para boa e 2 para ruim\n";
cin >> saude;
cout<< "digite sua idade\n";
cin >> idade;
cout << "digite sua altura em centimetros\n";
cin >> altura;

if (sexo==1 and saude==1 and idade==18 and altura>=170 )
{
    cout << "bem vindo ao exercito soldado "<<nome<<"\n";
}
else
{
    cout << ""<<nome<<" voce foi liberado\n";
}

cout << "saldado 3\n";
cout << "digite seu nome\n";
cin >> nome;
cout << "digite seu sexo sendo 1 para masculino e 2 para feminino \n";
cin >> sexo;
cout << "digite sua saude sendo 1 para boa e 2 para ruim\n";
cin >> saude;
cout<< "digite sua idade\n";
cin >> idade;
cout << "digite sua altura em centimetros\n";
cin >> altura;

if (sexo==1 and saude==1 and idade==18 and altura>=170 )
{
    cout << "bem vindo ao exercito soldado "<<nome<<"\n";
}
else
{
    cout << ""<<nome<<" voce foi liberado\n";
}

cout<< "saldado 4\n";
cout << "digite seu nome\n";
cin >> nome;
cout << "digite seu sexo sendo 1 para masculino e 2 para feminino \n";
cin >> sexo;
cout << "digite sua saude sendo 1 para boa e 2 para ruim\n";
cin >> saude;
cout<< "digite sua idade\n";
cin >> idade;
cout << "digite sua altura em centimetros\n";
cin >> altura;

if (sexo==1 and saude==1 and idade==18 and altura>=170 )
{
    cout << "bem vindo ao exercito soldado "<<nome<<"\n";
}
else
{
    cout << ""<<nome<<" voce foi liberado\n";
}

cout <<"saldado 5\n";
cout << "digite seu nome\n";
cin>> nome;
cout << "digite seu sexo sendo 1 para masculino e 2 para feminino \n";
cin >> sexo;
cout << "digite sua saude sendo 1 para boa e 2 para ruim\n";
cin >> saude;
cout<< "digite sua idade\n";
cin >> idade;
cout << "digite sua altura em centimetros\n";
cin >> altura;

if (sexo==1 and saude==1 and idade==18 and altura>=170 )
{
    cout << "bem vindo ao exercito soldado "<<nome<<"\n";
}
else
{
    cout << ""<<nome<<" voce foi liberado\n";
}

system ("pause");
return 0;
}
