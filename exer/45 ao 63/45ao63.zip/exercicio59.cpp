// Exerc�cio 59
// Dados tr�s valores A, B e C, em que A e B s�o n�meros reais e C � um caractere,
// pede se para imprimir o resultado da opera��o de A por B se C for um s�mbolo de
// operador aritm�tico caso contr�rio deve ser impressa uma mensagem de
// operador n�o definido Tratar erro de divis�o por zero



#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <locale.h>

using namespace std;

main()
{
	setlocale(LC_ALL, "Portuguese");
	int a=0,b=0,c=0;


	cout<<"Digite o valor A: " <<endl;
	cin>> a;

	cout<<"Digite o valor de B: " <<endl;
	cin>> b;

    cout << " \n 1. Soma "<<endl;
    cout << " \n 2. Subtra��o "<<endl;
    cout << " \n 3. Multiplica��o "<<endl;
    cout << " \n 4. Divis�o "<<endl;

	cout << " \n Digite a op��o desejada: "<<endl;
    cin >> c;

	//resolucao
    switch (c)
    {
           case 1:
                c= a+b;
                cout<<  "A soma "<<a<<"+"<<b<< " = " <<c <<endl;
           break;
           case 2:
                c= a-b;
                 cout<<  "A subtra��o "<<a<<"-"<<b<< " = " <<c <<endl;
           break;
           case 3:
                c= a*b;
                 cout<<  "A multiplica��o "<<a<<"*"<<b<< " = " <<c <<endl;
           break;
            case 4:
            	if(b==0)
            	{
            	cout << " \n N�o existe divis�o por zero. "<<endl;
				}
				else
				{
				c= a/b;
                 cout<<  "A divis�o "<<a<<"/"<<b<< " = " <<c <<endl;
				}

           break;
           default:
           	cout << "  Operador n�o definido! "<<endl;
       }
	system("pause");
	return 0;
}
